This is Jonathan Van Hyning's and Ananya Thridandam's
final project for UCSD MAE204 WI24.

The main script for this project is:
/SimulateRobot/test_SimulateRobot.m 

The inputs for each trial are stored under:
/SimulateRobot/trials

Properties of KUKA youBot are stored in:
/SimulateRobot/robotinfo.m 

/Trajectory/Trajectory.m
/FeedbackControl/FeedbackControl.m
/NextState/NextState.m

Each of the following folders contain a funciton of 
the same name + some additional test functions that 
might help users interpret and use the code properly.

Best,
Jonathan and Ananya
